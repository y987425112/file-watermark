Placeholder class to retain directory in CVS so build scripts will work.
Part of directory standardization effort with jacobgen